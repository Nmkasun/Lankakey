rootProject.name = "LankaKey"
include(":app")
