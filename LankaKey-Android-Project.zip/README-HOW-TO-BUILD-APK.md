# How to Build LankaKey APK

## 🚀 3 Easy Ways to Build Your APK:

### Option 1: In Android Studio (Free & Recommended)
1. Download & install free **Android Studio** (from developer.android.com).
2. Click **Open Project** and select this unzipped folder.
3. Wait 1 minute for Gradle to sync.
4. Click top menu: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will notify: *"APK(s) generated successfully"*. Click **locate** to get `app-debug.apk`!
6. Copy `app-debug.apk` to your phone and tap to install!

### Option 2: Automatic Free GitHub Cloud APK Builder (No Computer Setup!)
1. Create a free repository on **GitHub.com**.
2. Upload these files to your repository.
3. Go to the **Actions** tab on your GitHub repo.
4. GitHub will automatically run the included `.github/workflows/build-apk.yml` workflow!
5. When finished (takes ~2 mins), click the workflow run and download **LankaKey-Debug-APK**!

### Option 3: Using "Website 2 APK Builder" (Windows App)
1. Download free *Website 2 APK Builder* on Windows.
2. Select "Local Website Folder" and select the `assets` directory.
3. Click "Generate APK".
